package umn.ac.id.musicplayer;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class LaguAdapter extends RecyclerView.Adapter<LaguAdapter.MyViewHolder> implements Filterable {
    private List<Lagu> mLaguList;
    private List<Lagu> mLaguListFiltered;
    private Context mContext;
    private SongAdapterListener listener;

    public LaguAdapter(Context context, List<Lagu> laguList, SongAdapterListener listener){
        this.mContext = context;
        this.mLaguList = laguList;
        this.listener = listener;
        this.mLaguListFiltered = laguList;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    mLaguListFiltered = mLaguList;
                } else {
                    List<Lagu> filteredList = new ArrayList<>();
                    for (Lagu row : mLaguList) {
                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getTitle().toLowerCase().contains(charString.toLowerCase()) || row
                                .getArtist().toLowerCase().contains(charSequence)) {
                            filteredList.add(row);
                        }
                    }
                    mLaguListFiltered = filteredList;
                }
                FilterResults filterResults = new FilterResults();
                filterResults.values = mLaguListFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mLaguListFiltered = (ArrayList<Lagu>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.lagu, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Lagu lagu = mLaguListFiltered.get(position);
        holder.title.setText(lagu.getTitle());
        holder.artist.setText(lagu.getArtist());
        Glide.with(mContext).load(lagu.getThumbnail()).placeholder(R.mipmap.ic_channel).error(R.mipmap.ic_channel)
                .crossFade().centerCrop().into(holder.thumbnail);
    }

    @Override
    public int getItemCount() {
        return mLaguListFiltered.size();
    }

    public void removeItem(int position){
        mLaguList.remove(position);
        // notify the item removed by position
        notifyItemRemoved(position);
    }

    public void restoreItem(Lagu item, int position){
        mLaguList.add(position, item);
        notifyItemInserted(position);
    }

    public interface SongAdapterListener{
        void onSongSelected(Lagu lagu);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView title, artist;
        public GridLayout viewBackground, viewForeground;
        public ImageView thumbnail;

        public MyViewHolder(View view) {
            super(view);
            title = view.findViewById(R.id.song_title);
            artist = view.findViewById(R.id.song_artist);
            viewBackground = view.findViewById(R.id.view_background);
            viewForeground = view.findViewById(R.id.view_foreground);
            thumbnail = view.findViewById(R.id.thumbnail);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // send selected contact in callback
                    listener.onSongSelected(mLaguListFiltered.get(getAdapterPosition()));
                }
            });
        }
    }
}